# SBoxLab measured experiment

Protocol: SBoxLab-image-v1

Machine: Linux-6.18.44-x86_64-with-glibc2.39

Exact decryption: True

KDF material generation is excluded from runtime measurements. Raw trials and environment versions are included. No secret key is exported.
